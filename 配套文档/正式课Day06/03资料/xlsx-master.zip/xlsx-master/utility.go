package xlsx

// sPtr simply returns a pointer to the provided string.
func sPtr(s string) *string {
	return &s
}
